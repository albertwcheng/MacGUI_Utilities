#!/usr/bin/env python2.7

'''

joinu.py

join substitute allowing unsorted files to be joined.


Copyright 2010 Wu Albert Cheng <albertwcheng@gmail.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

'''

#imports
from sys import stderr,stdout,argv
from getopt import getopt

#### albertcommon copied here



from math import floor
import sys
import types
import re
import os
from ConfigParser import ConfigParser
from random import shuffle,randint

def findNextCombinationOfIdx(N,k,idxV):
	for i in range(k-1,-1,-1):
		if idxV[i]<N-k+i:
			idxV[i]+=1
			#reset the higher levels:
			for j in range(i+1,k):
				idxV[j]=idxV[j-1]+1
			return True
	
	return False
	
def findAllCombinations(X,k): #find all k-subsets of X
	combinations=[]
	idxV=[]
	N=len(X)
	
	#init idxV
	for i in range(0,k):
		idxV.append(i)
	
	#this is the first combination
	combinations.append(getSubvector(X,idxV))
	
	#now proceed to find other combinations
	while findNextCombinationOfIdx(N,k,idxV):
		combinations.append(getSubvector(X,idxV))
	
	return combinations		

def NextCombinationOn(X,k,idxV=None):
	N=len(X)
	if idxV==None: #get the first combination and return the idxV new
		idxV=[]
		for i in range(0,k):
			idxV.append(i)
	elif not findNextCombinationOfIdx(N,k,idxV):
		return None,None
	
	return getSubvector(X,idxV),idxV
	
		


def String_findAll(s,sub,start=0,end=-1):
	if end!=-1:
		endSearch=end
	else:
		endSearch=len(s)
		
	curStart=start
	
	locations=[]
	
	while True:
		idx=s.find(sub,curStart,endSearch)
		if idx<0:
			break
			
		locations.append(idx)
		curStart=idx+1
	
	return locations	

def getAttrWithDefaultValue(attrMatrix,attrName,defaultValue):
	try:
		return attrMatrix[attrName]
	except KeyError:
		return defaultValue
		
def getLevel2AttrWithDefaultValue(attrMatrix,targetName,attrName,defaultValue):
	try:
		return attrMatrix[targetName][attrName]
	except KeyError:
		return defaultValue
	
def readNamedAttrMatrix(filename):
	'''
	!optkey1	optvalue1
	!optkey2	optvalue2
	Target	AttrName1	AttrName2	...
	target1	value(1,1)   ...
	target2   ...        ...
	:::::
	
	'''
	attrMatrix=dict()
	
	fil=open(filename)
	#print >> stderr,"opening config",filename
	
	lino=0
	for lin in fil:
		#print >> stderr,"reading",lin
		lin=lin.rstrip("\r\n")
		if len(lin)<1:
			continue
		elif lin[0]=='#':
			continue #commented lines
		elif lin[0]=='!':
			key,value=lin.split("\t") #keep the exclamation mark.
			attrMatrix[key]=value
			continue
		
		lino+=1  #only if row is not empty and is not !-options, increment lino
		
		
		
		fields=lin.split("\t")
	
		if lino==1:
			attrNames=fields[1:]
		else:
			targetName=fields[0]
			targetDict=dict()
			attrMatrix[targetName]=targetDict
			for attrName,value in zip(attrNames,fields[1:]):
				targetDict[attrName]=value
		
	fil.close()
	
	return attrMatrix
	
def RE_findOverlappingInstancesOfCompiledRegex(there, thestring):
	#total = 0
	start = 0
	#there = re.compile(pattern)
	locations=[]
	while True:
		mo = there.search(thestring, start)
		if mo is None: 
			return locations
		#total += 1
		moStart=mo.start()
		moEnd=mo.end()
		locations.append((moStart,moEnd))
 		start = 1 + moStart

	return locations

def RE_findOverlappingInstancesOfRegexString(pattern, thestring):
	return RE_findOverlappingInstancesOfCompiledRegex(re.compile(pattern),thestring)
	
	
def generic_istream(filename):
	#print >> stderr,"opening ",filename
	if filename=="-":
		return sys.stdin
	else:
		return open(filename)

def medianOfSortedList(L):
	lList=len(L)
	if lList%2==0:
		return (L[lList/2-1]+L[lList/2])/2.0
	else:
		return L[lList/2]

def sortedList(L):
	LC=L[:]
	LC.sort()
	return LC	

def multiplyVector(L,by):
	LC=[]
	for x in L:
		LC.append(x*by)
	
	return LC

def vectorComparator(v1,v2):
	try:
		for v1v,v2v in zip(v1,v2):
			if v1v<v2v:
				return -1
			elif v1v>v2v:
				return 1
				

	except IndexError:
		if len(v1v)<len(v2v):
			return -1
		elif len(v1v)>len(v2v):
			return 1
		else:
			#strange
			print >> sys.stderr,"strange",v1,v2
			return 0

	return 0



def SecondFieldComparator(x,y):
	if x[1]<y[1]:
		return -1
	elif x[1]>y[1]:
		return 1
	else:
		return 0

def ToIndexedTuples(L):
	IT=[]
	for i in range(0,len(L)):
		IT.append([i,L[i]])

	return IT

def rank(L,tieDivide):
	RANK=L[:]
	IT=ToIndexedTuples(L)
	IT.sort(SecondFieldComparator)
	#print >> sys.stderr,"IT is",IT
	if tieDivide:
		crank=0
		divider=1
		startI=0
		for curI in range(0,len(IT)+1):

			if curI!=len(IT):
				it=IT[curI]
				curValue=it[1]

			if curI==0:
				#startI=curI
				#divider=1
				prev=curValue
				continue #nothing else to do
				
			if prev!=curValue or curI==len(IT):
				if divider>1:
					thisRank=float(2*(crank+1)+divider-1)/2
				else:
					thisRank=crank+1
					
				for setI in range(startI,curI):
					RANK[IT[setI][0]]=thisRank
				
				if curI==len(IT):
					break

				crank+=divider
				startI=curI
				divider=1
				
				prev=curValue
			else:
				divider+=1
		
		
					
	else:
		for i,it in zip(range(0,len(IT)),IT):
			origindex,value=it
			RANK[origindex]=i+1
	
	return RANK


def StrListToFloatList(L):
	LC=[]
	for s in L:
		LC.append(float(s))
	return LC

def randomChooseK(X,k):
	combination=[]
	lowerchoice=0
	N=len(X)
	for i in range(0,k):
		thischoice=randint(lowerchoice,N-k+i)
		combination.append(X[thischoice])
		lowerchoice=thischoice+1
	
	return combination

def advRandomChooseK(X,k):
	combination=[]
	loconstraint=[]
	hiconstraint=[]
	N=len(X)
	posV=range(0,k)
	for i in posV:
		loconstraint.append(i)
		hiconstraint.append(N-k+i)
	#now shuffle
	shuffle(posV)
	for i in posV:
		#choose one from the constrained interval
		choice=randint(loconstraint[i],hiconstraint[i])
		combination.append(X[choice])
		
		hiconstraint[i]=choice
		loconstraint[i]=choice
		#now update the -1 and +1 constraint
		j=i #propagate down
		while j>0:
			hiconstraint[j-1]=min(loconstraint[j]-1,hiconstraint[j-1])
			j-=1
			
		j=i
		while j<k-1:
			loconstraint[j+1]=max(hiconstraint[j]+1,loconstraint[j+1])
			j+=1
			
	return combination
	
def advRandomChooseKNoRepeat(X,k,history,trials=1000):
	combination=advRandomChooseK(X,k)
	tcombination=tuple(combination)
	T=1
	while tcombination in history:
		T+=1
		if T>trials:
			return None
		combination=advRandomChooseK(X,k)
		tcombination=tuple(combination)
	
	history.add(tcombination)
	return combination
	


def randomChooseKNoRepeat(X,k,history,trials=1000):
	combination=randomChooseK(X,k)
	tcombination=tuple(combination)
	T=1
	while tcombination in history:
		T+=1
		if T>trials:
			return None
		combination=randomChooseK(X,k)
		tcombination=tuple(combination)
	
	history.add(tcombination)
	return combination
	
	
def randomShuffleNoRepeat(X,history,trials=1000):

	
	T=0
	
	while tuple(X) in history:
		T+=1
		if T>trials:
			return False
			
		shuffle(X)
	
	history.add(tuple(X))
	return True
		
def toStrList(L):
	LC=[]
	for i in L:
		LC.append(str(i))
	return LC


def medianOfList(L):

	return medianOfSortedList(sortedList(L))

def selectListByIndexVector(L,I):
		
	newL=[]
	try:	
		for i in I:
			newL.append(L[i])
		return newL
	except:
		return []

def percentileOfList(p,L):
	LSorted=L[:]
	LSorted.sort()	
	l=len(LSorted)
	i=int(round(float(l-1)*p))
	return LSorted[i]

def countIfInRangeInc(low,hi,L):
	c=0	
	for x in L:
		if low<=x and x<=hi:
			c+=1
	return c

def countIf(needles,L):
	c=0
	for x in L:
		if x in needles:
			c+=1
	return c	

def divMod(num,div):
	k=int(num)/int(div)
	d=int(num)%int(div)
	return k,d

def dissociatekd(n):
	k=floor(n)
	d=n-k
	return k,d

def percentilesOfSortedList(L,precentiles):
	N=len(L)
	RESULT=[]
	for percentile in precentiles:
		n=float(percentile)/100*(N-1)+1
		k,d=dissociatekd(n)
		if k==1:
			val=L[0]
		elif k==N:
			val=L[N-1]
		else:
			val=L[int(k-1)]+d*(L[int(k)]-L[int(k-1)])		
		
		RESULT.append(val)
	
	return RESULT

def percentilesOfList(L,percentiles):
	return percentilesOfSortedList(sortedList(L),percentiles)


def outlierBounds(L):
	LQ,UQ=percentilesOfList(L,[25,75])
	IQ=UQ-LQ
	return LQ-1.5*IQ,UQ+1.5*IQ


def rangeListFromRangeString(rangestring,transform):
	rangeValues=[]
	rangestring=rangestring.strip()
	if rangestring=='0' or rangestring=='-' or rangestring=="":
		return rangeValues #mod 3/31/2009

	col1splits=rangestring.split(",")
	for col1split in col1splits:
		col1rangesplit=col1split.split("-")
		if len(col1rangesplit)==1:
			rangeValues.append(int(col1rangesplit[0])+transform)
		else:
			try:
				for coltoAdd in range(int(col1rangesplit[0])+transform,int(col1rangesplit[1])+1+transform):
					rangeValues.append(coltoAdd)
			except ValueError:
				pass	
			
	return rangeValues	


def multiColJoinField(headerFields,val):
	#print >> sys.stderr, val
	
	
	splitons=val.split("%")

	#print >> sys.stderr,splitons
	filename=splitons[0]
	
	if len(splitons)>1:
		sep=replaceSpecialChar(splitons[1])
	else:
		sep="\t"
	
	istream= generic_istream(filename)
	
	fieldsToInclude=[]

	for line in istream:
		line=line.strip("\r\n")
		fieldsToInclude.extend(line.split(sep))
	
	indices=dict()	
	
	indRange=range(0,len(headerFields))
	for i,headerF in zip(indRange,headerFields):				
		if headerF in fieldsToInclude:
			if not indices.has_key(headerF):
				indices[headerF]=[i]
			else:
				indices[headerF].append(i)

	istream.close()
	
	#print >> sys.stderr,indices
	indicesOut=[]

	for fieldToInclude in fieldsToInclude:
		try:
			indicesOut.extend(indices[fieldToInclude])
		except KeyError:
			pass
	#print >> sys.stderr,indicesOut
	return indicesOut

def rangeListFromRangeStringAdv(headerFields,rangestring,transform):
	rangeValues=[]
	rangestring=rangestring.strip()
	if rangestring=='0' or rangestring=='-' or rangestring=="":
		return rangeValues #mod 3/31/2009
	


	
	sortMode=0 #0:no sort, 1: ascending, -1: descending
	
	col1splits=rangestring.split(",")
	for curColSplitI in range(0,len(col1splits)):
		col1split=col1splits[curColSplitI]
		col1rangesplit=col1split.split("-")
		
		for i in range(0,len(col1rangesplit)):
			#print col1rangesplit[i],
			col1rangesplit[i]=replaceSpecialChar(col1rangesplit[i])
			#print col1rangesplit[i]

		if len(col1rangesplit)==1:
			director=col1rangesplit[0][0]
			
			adder=0
			
			if ">>" in col1rangesplit[0]:
				col1rangesplitsplit=col1rangesplit[0].split(">>")
				col1rangesplit[0]=col1rangesplitsplit[0]
				adder=int(col1rangesplitsplit[1])
				
			elif "<<" in col1rangesplit[0]:
				col1rangesplitsplit=col1rangesplit[0].split("<<")
				col1rangesplit[0]=col1rangesplitsplit[0]
				adder=-int(col1rangesplitsplit[1])			
				
			if director in [".","@","%"]: #it's a header string!
				if director=='.':
					indices=multiColIndicesFromHeaderMerged(headerFields,[col1rangesplit[0][1:]])
				elif director=="%":
					indices=multiColJoinField(headerFields,col1rangesplit[0][1:])				
				else:
					p=re.compile(col1rangesplit[0][1:])
					indices=multiColIndicesFromHeaderMerged(headerFields,[p])
				if(len(indices)==0):
					print >> sys.stderr,"Error:",col1rangesplit[0][1:],"not found/matched in header"	
					sys.exit()
			
				for inx in indices:
					rangeValues.append(inx+1+transform+adder)
				
			elif director=='_':
				rangeValues.append(len(headerFields)-int(col1rangesplit[0][1:])+1+transform)
			elif director=='a':
				sortMode=1
			elif director=='d':
				sortMode=-1
			elif director=='+':
				rangeValues.extend(range(0,len(headerFields)))
			elif director=='x':
				#added 7/15/2010 for excel styled column id
				rangeValues.append(excelIndxToCol0(col1rangesplit[0][1:])+1+transform) #converted back to 1-based and then do transform
			else:
				rangeValues.append(int(col1rangesplit[0])+transform)
		else: # x-x a range!
			try:
				#handle the left value of the bound
				adderL=0
				adderR=0
				
				if ">>" in col1rangesplit[0]:
					col1rangesplitsplit=col1rangesplit[0].split(">>")
					col1rangesplit[0]=col1rangesplitsplit[0]
					adderL=int(col1rangesplitsplit[1])
				elif "<<" in col1rangesplit[0]:
					col1rangesplitsplit=col1rangesplit[0].split("<<")
					col1rangesplit[0]=col1rangesplitsplit[0]
					adderL=-int(col1rangesplitsplit[1])	
				
				if ">>" in col1rangesplit[1]:
					col1rangesplitsplit=col1rangesplit[1].split(">>")
					col1rangesplit[1]=col1rangesplitsplit[0]
					adderR=int(col1rangesplitsplit[1])
				elif "<<" in col1rangesplit[1]:
					col1rangesplitsplit=col1rangesplit[1].split("<<")
					col1rangesplit[1]=col1rangesplitsplit[0]
					adderR=-int(col1rangesplitsplit[1])	
									
				if col1rangesplit[0][0]=='.':
					#print >> sys.stderr, headerFields
					indices=multiColIndicesFromHeaderMerged(headerFields,[col1rangesplit[0][1:]])
					if(len(indices)==0):
						print >> sys.stderr,"Error:",col1rangesplit[0][1:],"not found in header"	
						sys.exit()
					rangeL=min(indices)+1+transform+adderL
				elif col1rangesplit[0][0]=='@': #added 12/10/2009
					p=re.compile(col1rangesplit[0][1:])
					indices=multiColIndicesFromHeaderMerged(headerFields,[p])
					if(len(indices)==0):
						print >> sys.stderr,"Error:",col1rangesplit[0][1:],"not matched in header"	
						sys.exit()	
					rangeL=min(indices)+adderL
				elif col1rangesplit[0][0]=='_': #from the back added 12/10/2009
					rangeL=len(headerFields)-int(col1rangesplit[0][1:])+1+transform
				elif col1rangesplit[0][0]=='x':
					#added 7/15/2010 for excel styled column id
					rangeL=excelIndxToCol0(col1rangesplit[0][1:])+1+transform #converted back to 1-based and then do transform
				else:
					rangeL=int(col1rangesplit[0])+transform

				#handle the right value of the bound
				if col1rangesplit[1][0]=='.':
					indices=multiColIndicesFromHeaderMerged(headerFields,[col1rangesplit[1][1:]])
					if(len(indices)==0):
						print >> sys.stderr,"Error:",col1rangesplit[1][1:],"not found in header"	
						sys.exit()
					rangeH=max(indices)+2+transform+adderR
				elif col1rangesplit[1][0]=='@':
					p=re.compile(col1rangesplit[1][1:])
					indices=multiColIndicesFromHeaderMerged(headerFields,[p])
					if(len(indices)==0):
						print >> sys.stderr,"Error:",col1rangesplit[1][1:],"not matched in header"	
						sys.exit()						
					rangeH=max(indices)+2+transform+adderR
				elif col1rangesplit[1][0]=='_': #from the back added 12/10/2009
					rangeH=len(headerFields)-int(col1rangesplit[1][1:])+2+transform
				elif col1rangesplit[1][0]=='x':
					#added 7/15/2010 for excel styled column id
					rangeH=excelIndxToCol0(col1rangesplit[1][1:])+2+transform #converted back to 1-based and then do transform
				else:
					rangeH=int(col1rangesplit[1])+1+transform
				
				
				if rangeL>=rangeH:
					step=-1
					rangeH-=2
				else:
					step=1
				#print >> sys.stderr,rangeL,rangeH,step
				for coltoAdd in range(rangeL,rangeH,step):
					rangeValues.append(coltoAdd)
			
			except ValueError:
				pass	
	
	if sortMode==1:
		rangeValues.sort()
	elif sortMode==-1:
		rangeValues.sort()
		rangeValues.reverse()

	return rangeValues


def meanOfList(L):
	#print L
	return float(sum(L))/len(L)
	

def removeOutliers(L):
	if len(L)<3:
		return
	LB,UB=outlierBounds(L)
	for i in range(len(L)-1,-1,-1):
		if L[i]>UB or L[i]<LB:
			del L[i]


def getCol0ListFromCol1ListString(col1ValueString):
	
	return rangeListFromRangeString(col1ValueString,-1)

def getCol0ListFromCol1ListStringAdv(headerFields,col1ValueString):
	
	return rangeListFromRangeStringAdv(headerFields,col1ValueString,-1)

def sortu(L):
	return uniq(sortedList(L))

def uniq(L):
	LKey=[]
	UL=[]
	for l in L:
		if l not in LKey:		
			LKey.append(l)
			UL.append(l)

	return UL

MAX_INT=sys.maxint
MIN_INT=-MAX_INT-1


specialCharMap={ "\\t":"\t",
		 "\\n":"\n",
		 "\\r":"\r",
		 "^t":"\t",
		 "^b":" ",
		"^s":"<",
		"^g":">",
		"^c":",",
		"^d":".",
		"^^":"^",
		"^M":"$",
		"^m":"-",
		"^o":":",
		"^S":"\\"

		}




def replaceSpecialChar(S):
	for k,v in specialCharMap.items():
		#print >> sys.stderr, k#+"<"+S,
		S=S.replace(k,v)
	#print >> sys.stderr, S
	return S	

def mapSpecialChar(c,default):
	try:
		return specialCharMap[c]
	except KeyError:
		return default

def colIndicesFromHeader(headerFields,selectors):
	colIndices0=[]
	for selector in selectors:
		try:
			colIndices.append(headerFields.index(selector))
		except ValueError: #not found!
			colIndices.append(-1)

	return colIndices0

def indexAll(L,x):
	indices=[]
	start=0
	if type(x) is types.StringType:
		for i in range(0,len(L)):
			if x==L[i]:
				indices.append(i)
		
	else: # assume regex
		for i in range(0,len(L)):
			if x.search(L[i]) is not None:
				indices.append(i)
	

	return indices	

def multiColIndicesFromHeaderWithSelector(headerFields,selectors):
	colIndices0=[]
	for selector in selectors:
		colIndices0.append([selector,indexAll(headerFields,selector)])

	return colIndices0
	
def multiColIndicesFromHeaderMerged(headerFields,selectors):
	colIndices0=[]
	for selector in selectors:
		colIndices0.extend(indexAll(headerFields,selector))

	return colIndices0

def getHeader(filename,headerRow,startRow,FS):
	try:
		fil=generic_istream(filename)
	except IOError:
		print >> sys.stderr,"Cannot open",filename
		return
	
	header=[]
	prestartRows=[]
	c=0;
	for lin in fil:
		c+=1;
		
		if(c==headerRow):
			lin=lin.rstrip()
			if FS=="":
				header=lin.split()
			else:
				header=lin.split(FS)
		
		if(c<startRow):
			lin=lin.rstrip()
			if FS=="":
				prestartRows.append(lin.split())
			else:
				prestartRows.append(lin.split(FS))		
	
		if(c>=startRow):
			break
	fil.close()	

	return header,prestartRows

def explainColumns(stream):
	print >> stream,"cols format:"
	print >> stream,"\t* inserts all columns"
	print >> stream,"\tnumber: 1-5,3"
	print >> stream,"\tnumber preceded by '_' means from the end. _1 means last row, _2 second last"
	print >> stream,"\tfield name preceded by '.': .exp-5,.pvalue-.fdr"
	print >> stream,"\texcel column preceded by 'x': xB-xAA means column 2 to column 27"
	print >> stream,"\tregex preceded by '@': @FDR[a-z]"
	print >> stream,"\t>> after . and @ objects mean move right by one column"
	print >> stream,"\t<< after . and @ objects mean move left by one column"
	print >> stream,"\t%filename%sep or just %filename: open file which contains the fields to include. default separator is [TAB]"
	print >> stream,"\tif last field is a. Then following columns are added as ascending. If appears at end, all are sorted ascending"
	print >> stream,"\tis last field is d. Then following columns are added as descending. If appears at end, all are sorted descending"
	

def getSubvector(D,I,sortIndex=False):
	subv=[]
	nI=I	
	if sortIndex:	
		nI=I[:]
		nI.sort()

	for i in nI:
		subv.append(D[i])

	return subv	


def getSubVectorByBinarySelector(D,I):
	subv=[]
	for i,d in zip(I,D):
		if i:
			subv.append(d)

	return subv
	
def getSubVectorByReverseBinarySelector(D,I):
	subv=[]
	for i,d in zip(I,D):
		if not i:
			subv.append(d)

	return subv

def toStrVector(V):
	sV=[]
	for v in V:
		sV.append(str(v))
	return sV

def excelColIndex(idx0):
	k,d=divMod(idx0,26)
	D=[d]
	while k>=1:
		k,d=divMod(k-1,26)
		D.append(d)
	outString=""
	for d in D:
		outString=chr(ord('A')+(d))+outString

	return outString

def excelIndxToCol0(alphaString):
	idx=0
	multiplier=1
	for i in range(len(alphaString)-1,-1,-1):
		idx+=(ord(alphaString[i])-ord('A')+1)*multiplier
		multiplier*=26

	return idx-1

def testExcelString():
	for idx0 in range(0,20000):
		print >> stderr,(idx0+1),
		excelString=excelColIndex(idx0)
		print >> stderr,"excel="+excelString,
		rcol0=excelIndxToCol0(excelString)
		print >> stderr,"reverted="+str(rcol0+1)
		if rcol0!=idx0:
			print >> stderr,"error"
			exit()

def basename(filename):
	return os.path.basename(filename)

def cleanfilename(filename):
	bn=basename(filename)
	bn=bn.split(".")
	if len(bn)>1:
		del bn[-1]
	
	return ".".join(bn)

#from [ [1,2,3],[1],[1,2] ] => [ [1,1,1],[1,1,2],[2,1,1],[2,1,2],[3,1,1],[3,1,2] ]
def findAllCombinations(ListOfLists):
	numberOfPositions=len(ListOfLists)
	numberOfCombinations=1
	bounds=[]
	current=[]	
	for L in ListOfLists:
		numInList=len(L)
		numberOfCombinations*=numInList
		bounds.append(numInList)
		current.append(0)

	combinations=[]
	current[-1]=-1


	for cI in range(0,numberOfCombinations):
		thisCombination=[]
		#thisIndex=[]
		combinations.append(thisCombination)
		OK=False
		indexI=numberOfPositions-1
		while not OK:
			if current[indexI]==bounds[indexI]-1:
				#reset this and keep status to not OK
				current[indexI]=0		
			else:
				current[indexI]+=1
				OK=True
			#push current element to front
			#print >> stderr,current
			thisCombination.insert(0,ListOfLists[indexI][current[indexI]])
			#thisIndex.insert(0,current[indexI])
			indexI-=1

		while indexI>=0:
			thisCombination.insert(0,ListOfLists[indexI][current[indexI]])
			indexI-=1

		#print >> thisIndex

	return combinations


def preprocessFileLoadableArgs_inner_formkeystring(key,extraPrefix=""):
	prefix=""
	if key[0]!="-":
		if len(key)==1:
			prefix="-"
		else:
			prefix="--"
	
	
	key=key.replace("_","-")
	key=key.replace(" ","-")
	
	return prefix+extraPrefix+key
	
def preprocessFileLoadableArgs_helpmsg():
	return """import args from files
	--@import-args	filename
	import args from filename formatted <key><TAB><value>[[<TAB><value>]...]
	--@import-cfg filename
	import args from filename formatted as config file format
	[section_name]
	<key>=<value>[[<TAB><value>]...]
	if section_name is main,default,defaults,or ' ', or key is already prefixed by "-", then key is not (additionally) prefixed
	else key is prefixed by <section_name>-
	
	all " ",_ in key are replaced by "-" """

def preprocessFileLoadableArgs(args=sys.argv):
	i=0
	newArgs=[]
	while i<len(args):
		avalue=args[i]
		if avalue=="--@import-args":
			#--import-args filename
			#consume [i:i+2]		
			try:
				filename=args[i+1]
			except:
				print >> stderr,"not enough arg for --import-args. Need --import-args <filename>"
				raise ValueError
			
			
			fil=open(filename)
			
			for lin in fil:
				lin=lin.rstrip("\r\n")
				fields=lin.split("\t")
				key=fields[0]
				values=fields[1:]
				#now append!
				key=preprocessFileLoadableArgs_inner_formkeystring(key)
				newArgs.append(key)
				newArgs.extend(values)
				
			
			fil.close()
			i+=1
		elif avalue=="--@import-cfg":
			#--import-cfg configfilename
			#consume [i:i+2]
			try:
				filename=args[i+1]	
			except:
				print >> stderr,"not enough arg for --import-args. Need --import-cfg <configfilename>"
				raise ValueError
			
			configparser=ConfigParser()
			configparser.read(filename)
			sections=configparser.sections()
			for section in sections:
				sectionItems=configparser.items(section)
				for key,value in sectionItems:
					
					value=value.split("\t")
					
					if key[0]!="-":
						if section not in ["main","MAIN"," ","__main__","__MAIN__","defaults","default","DEFAULT","DEFAULTS"]:
							key=preprocessFileLoadableArgs_inner_formkeystring(key,section+"-")
						else:
							key=preprocessFileLoadableArgs_inner_formkeystring(key)
					
					#now append!
					newArgs.append(key)
					newArgs.extend(value)
			i+=1
		else:
			newArgs.append(avalue)
		
		i+=1 #prepare to go to next

	return newArgs
		
def debugFindAllCombinations():
	print >> stderr, findAllCombinations([ [1,2,3],[1],[1,2] ])
	print >> stderr, findAllCombinations([ ['amy','fiona','kate'],['likes','hates','kisses'],['jason','albert'] ])
	exit()





### end of albertcommon



#getFileOrderedKeyLines
#open file
#append to keys the keyCol0 col
#append to lines the whole line
#return keys,lines as a tuple
def getFileOrderedKeyLines(filename,keyCol0,separator,keyInternalSeparator,maxKey0,warningLevel,warnDuplicateKeys,stripFields,headerRow,fhreplace):
	try:
		f=open(filename)
	except IOError:
		print >> stderr,"Cannot open file",filename
		exit() #added 2010/8/1
	
	keys=[]
	lines=[]
	
	
	if warningLevel >=1 and warnDuplicateKeys:
		keySet=set()
		dupl=0

	maxFNumber=-1000
	
	
	lino=0 #line counter
	
	for line in f:
		lino+=1
		line=line.rstrip("\r\n") #remove carriage return at end of line
		splits=line.split(separator) #split
		if len(splits)<=maxKey0: #error requesting col out of range, ignore that line
			print >> stderr,filename,"line",lino,"has not enough splits:",splits
			continue
			
		if stripFields:
			stripL(splits)
		
		if lino==headerRow:
			replaceValuesByDict(splits,fhreplace)
				
		maxFNumber=max(maxFNumber,len(splits))	
		key=[]
		for keyCol in keyCol0:
			key.append(splits[keyCol])
		
		key=keyInternalSeparator.join(key)
		
		if warnDuplicateKeys:
			if key in keySet:
				dupl+=1
				if warningLevel>=2:
					print >> stderr,"duplicate key",key,"found in file",filename

			keySet.add(key)

		keys.append(key) #append key extracted from the keyCol0 column to keys
		lines.append(splits) #append line to lines #instead, append fields
	
	
	f.close() #close file

	if warningLevel>=1 and warnDuplicateKeys and dupl>0:
		print >> stderr,dupl,"lines of duplicate keys (not including the orginial ones) found in file",filename

	return keys,lines,maxFNumber #return the tuple
	
	
def stripL(L):
	for i in range(0,len(L)):
		L[i]=L[i].strip()
		
def replaceValuesByDict(L,D):
	if len(D)<1:
		return
	for i in range(0,len(L)):
		if L[i] in D:
			L[i]=D[L[i]]	
					
#getKeyedLines
#open file
#KeyedLines[key][] store lines with the same key in their order of appearance 
#fill up KeyedLines[][]
#return it
def getKeyedLines(filename,keyCol0,separator,keyInternalSeparator,maxKey0,warningLevel,warnDuplicateKeys,stripFields,headerRow,fhreplace):
	try:
		f=open(filename)
	except IOError:
		print >> stderr,"Cannot open file",filename
		exit() #added 2010/8/1
	
	KeyedLines=dict()
	
	if warningLevel>=1 and warnDuplicateKeys:
		dupl=0

	 
	lino=0 #line counter
	maxFNumber=-1000
	for line in f:
		lino+=1
		
		line=line.rstrip("\r\n") #remove carriage return at end of line
		splits=line.split(separator) #split
		if len(splits)<=maxKey0: #requesting out of range, ignore line
			print >> stderr,filename,"line",lino,"has not enough splits:",splits
			continue
		
		
		if stripFields:
			stripL(splits)
		
		if lino==headerRow:
			replaceValuesByDict(splits,fhreplace)
		
		maxFNumber=max(maxFNumber,len(splits))

		key=[]
		for keyCol in keyCol0:
			key.append(splits[keyCol])
		
		key=keyInternalSeparator.join(key)

		
		if not KeyedLines.has_key(key): #if key exist, get the list that store the lines with same key, if not create a new list
			CoKeyRow=[]
			KeyedLines[key]=CoKeyRow
		else:
			if warnDuplicateKeys:
				if warningLevel>=1:
					dupl+=1
					if warningLevel>=2:
						print >> stderr,"duplicate key",key,"found in file",filename
			
			CoKeyRow=KeyedLines[key]
		
		CoKeyRow.append(splits) #append line into the list as fields
		
		
	
	f.close() 
	if warningLevel>=1 and warnDuplicateKeys and dupl>0:
		print >> stderr,dupl,"lines of duplicate keys (not including the orginial ones) found in file",filename

	return KeyedLines,maxFNumber


def removeColumns(fields,col0toRemoveSortedReverse):
	for col0 in col0toRemoveSortedReverse:
		del fields[col0]

def repeat(element,times):
	arr=[]
	for i in range(0,times):
		arr.append(element)

	return arr
	

def joinFiles(ofilename,filename1,filename2,file1f0,file2f0,separator,printFile2Only,skipKeyColFile2,keyInternalSeparator,warningLevel,includeEveryFile1Rows,File2FillIn,warnDuplicateKeys,replaceFile1ColsByFile2,replaceFile1ColsByFile2Cols,stripFields,f1hreplace,f2hreplace,headerRow,prefixfile1line1,prefixfile2line1):

	ofil=open(ofilename,"w")
	#get the Keys and lines in order from file1
	File1Keys,File1Lines,maxFNumber1=getFileOrderedKeyLines(filename1,file1f0,separator,keyInternalSeparator,max(file1f0),warningLevel,warnDuplicateKeys,stripFields,headerRow,f1hreplace)
	
	#get the Key => Lines dictionary from file 2
	KeyedLinesFile2,maxFNumber2=getKeyedLines(filename2,file2f0,separator,keyInternalSeparator,max(file2f0),warningLevel,warnDuplicateKeys,stripFields,headerRow,f2hreplace)
	
	#maxColNumber=maxFNumber1+maxFNumber2
	
	file2f0sorted=file2f0[:]
	file2f0sorted.sort()
	file2f0sorted.reverse()
	
	#maxColNumbers=0

	maxJoinedColNumber=-1000
	
	joined_lines=[]

	lino=0

	#for each key and line in the ordered list from file1
	matchedLines=0
	unmatchedLines=0
	for key,line1 in zip(File1Keys,File1Lines):
		lino+=1
		try:
			CoKeyRowsFile2=KeyedLinesFile2[key] #find all the lines with that key in file 2 dictionary
			matchedLines+=1
			if replaceFile1ColsByFile2:
				rowFile2=CoKeyRowsFile2[-1] #the last one used		
				toPrint=line1[:]	
				#print >> stderr,replaceFile1ColsByFile2Cols	

				replaceFile1ColsByFile2_File1Cols,replaceFile1ColsByFile2_File2Cols=replaceFile1ColsByFile2Cols
				for replaceFile1ColsByFile2_File1Col,replaceFile1ColsByFile2_File2Col in zip(replaceFile1ColsByFile2_File1Cols,replaceFile1ColsByFile2_File2Cols):
					
					try:					
						newValue=rowFile2[replaceFile1ColsByFile2_File2Col]				
					except IndexError:
						continue  ##rowFile2 doesn't have that column

					try:
						toPrint[replaceFile1ColsByFile2_File1Col]=newValue
					except IndexError:
						needed=replaceFile1ColsByFile2_File1Col-len(toPrint)
						for x in range(0,needed):
							toPrint.append("")
						toPrint.append(newValue)

				joined_lines.append(toPrint)
			else:
				for rowFile2 in CoKeyRowsFile2:
					if len(joined_lines)==0: #first line to be outputed
						if len(prefixfile1line1)>0:
							for i in range(0,len(line1)):
								if i not in file1f0: #not a key
									line1[i]=prefixfile1line1+line1[i]
						if len(prefixfile2line1)>0:
							for i in range(0,len(rowFile2)):
								if i not in file2f0: #not a key
									rowFile2[i]=prefixfile2line1+rowFile2[i]
									
					
					toPrint=[] #""
					if not printFile2Only: #print also file 1
						toPrint+=line1
					
					if skipKeyColFile2: #print the key col of file 2 also?
						rowFile2splitsClone=rowFile2[:]
						removeColumns(rowFile2splitsClone,file2f0sorted)
						toPrint+=rowFile2splitsClone
					else:	
						toPrint+=rowFile2
				
					joined_lines.append(toPrint)
					maxJoinedColNumber=max(maxJoinedColNumber,len(toPrint))
				
		except KeyError: #key not found in file2
				unmatchedLines+=1
				
				if warningLevel>=2:
					print >> sys.stderr,"line",lino,"of File 1 with key",key,"not found in File 2"

				if replaceFile1ColsByFile2:
					#simply just output line1 without modification
					joined_lines.append(line1[:])
				else:
					if includeEveryFile1Rows:
						if not printFile2Only:
							toPrint=line1[:]						
							joined_lines.append(toPrint)
							maxJoinedColNumber=max(maxJoinedColNumber,len(toPrint))

							
	if warningLevel>=1:
		print >> sys.stdout,matchedLines,"lines of File1 matched and",unmatchedLines,"lines unmatched"

	#print >> stderr,joined_lines

	for i in range(0,len(joined_lines)):
		toPrint=joined_lines[i]

		if includeEveryFile1Rows:
		#need to fill in
			numColsToFill=maxJoinedColNumber-len(toPrint)
			for j in range(0,numColsToFill):
				toPrint.append(File2FillIn)

		print >> ofil,separator.join(toPrint)
	ofil.close()


	

def joinu_Main():
	programName=argv[0]
	optlist,argvs=getopt(argv[1:],'1:2:rck:t:h:f:w:W:s',['replace-file1-cols-by-file2-cols-on-joined-items=','r1=','r2=','with=','12=','prefix-first-line-of-file-1=','prefix-first-line-of-file-2='])
	headerRow=1

	if len(argvs)<2:
		print >> stderr,"Usage:",programName," filename1 filename2 ofilename"
		print >> stderr,"Options:"
		print >> stderr,"-1 col1forFile1 (support multiple columns)"
		print >> stderr,"-2 col1forFile2 (support multiple columns)"
		print >> stderr,"--12 col1for both files"
		print >> stderr,"--r1 A --with B. Replace header field of file1 from A to B"
		print >> stderr,"--r2 A --with B."
		print >> stderr,"-t separator"
		print >> stderr,"-r :print file 2 only"
		print >> stderr,"--replace-file1-cols-by-file2-cols-on-joined-items columns  (keeping all file1 lines, replace only when matched)"
		print >> stderr,"-c :include the key col of file 2"
		print >> stderr,"-k keyInternalSeparator : how to join key column strings"
		print >> stderr,"-h headerRow"
		print >> stderr,"-f placeholder. Fill in the empty columns by placeholder if File1 row is not found in File2"
		print >> stderr,"-w warningLevel. Warning print to stderr. 0=no warning, 1=print the number of lines matched and unmatched at the end, 2=print every instances of unmatching, and the total number at the end"
		print >> stderr,"-Wd warn duplicate keys in files"
		print >> stderr,"-s  strip fields"
		print >> stderr,"--prefix-first-line-of-file-1 p"
		print >> stderr,"--prefix-first-line-of-file-2 p"
		explainColumns(stderr)
		return
		
	filename1,filename2,ofilename=argvs;
	
	file1f0=[0]
	file2f0=[0]
	separator='\t'
	printFile2Only=False
	skipKeyColFile2=True
	keyInternalSeparator="\t"
	warningLevel=1
	includeEveryFile1Rows=False
	File2FillIn="."
	warnDuplicateKeys=False
	replaceFile1ColsByFile2=False
	replaceFile1ColsByFile2Cols=[]
	stripFields=False
	headerFieldReplaceeSelector=0
	headerFieldReplaceeKey=""
	f1hreplace=dict()
	f2hreplace=dict()
	prefixfile1line1=""
	prefixfile2line1=""
	for k,v in optlist:
		if k=="-h":
			headerRow=int(v)
	
		elif k=='-1':
			try:
				file1f0=getCol0ListFromCol1ListString(v)
			except ValueError:
				header,prestarts=getHeader(filename1,headerRow,headerRow+1,separator)
				if stripFields:
					stripL(header)
				replaceValuesByDict(header,f1hreplace)
				file1f0=getCol0ListFromCol1ListStringAdv(header,v)	

		elif k=='-2':	
			try:
				file2f0=getCol0ListFromCol1ListString(v)
			except ValueError:
				header,prestarts=getHeader(filename2,headerRow,headerRow+1,separator)
				if stripFields:
					stripL(header)				
				replaceValuesByDict(header,f2hreplace)
				file2f0=getCol0ListFromCol1ListStringAdv(header,v)				
		elif k=='--12':
			try:
				file1f0=getCol0ListFromCol1ListString(v)
			except ValueError:
				header,prestarts=getHeader(filename1,headerRow,headerRow+1,separator)
				if stripFields:
					stripL(header)
				replaceValuesByDict(header,f1hreplace)
				file1f0=getCol0ListFromCol1ListStringAdv(header,v)
				
			try:
				file2f0=getCol0ListFromCol1ListString(v)
			except ValueError:
				header,prestarts=getHeader(filename2,headerRow,headerRow+1,separator)
				if stripFields:
					stripL(header)				
				replaceValuesByDict(header,f2hreplace)
				file2f0=getCol0ListFromCol1ListStringAdv(header,v)				
		elif k=='-t':
			separator=replaceSpecialChar(v)	
		elif k=='-r':
			printFile2Only=True
			skipKeyColFile2=False
		elif k=='-c':
			skipKeyColFile2=False
		elif k=='-k':
			keyInternalSeparator=replaceSpecialChar(v)
		elif k=='-w':
			warningLevel=int(v)
		elif k=='-f':
			includeEveryFile1Rows=True
			File2FillIn=v
		elif k=='-W':
			if v=='d':			
				warnDuplicateKeys=True
			else:
				print >> stderr,"unknown warning category","-"+k+v
				printUsageAndExit(programName)
		elif k=='--replace-file1-cols-by-file2-cols-on-joined-items':
			replaceFile1ColsByFile2=True
			header,prestarts=getHeader(filename2,headerRow,headerRow+1,separator)
			if stripFields:
				stripL(header)			
			replaceValuesByDict(header,f2hreplace)
			replaceFile1ColsByFile2_File2Cols=getCol0ListFromCol1ListStringAdv(header,v)	
			header,prestarts=getHeader(filename1,headerRow,headerRow+1,separator)
			if stripFields:
				stripL(header)				
			replaceValuesByDict(header,f1hreplace)
			replaceFile1ColsByFile2_File1Cols=getCol0ListFromCol1ListStringAdv(header,v)			
			replaceFile1ColsByFile2Cols=(replaceFile1ColsByFile2_File1Cols,replaceFile1ColsByFile2_File2Cols)
		elif k=='-s':
			stripFields=True
		elif k=='--r1':
			headerFieldReplaceeSelector=1
			headerFieldReplaceeKey=v
		elif k=='--r2':
			headerFieldReplaceeSelector=2
			headerFieldReplaceeKey=v
		elif k=='--prefix-first-line-of-file-1':
			prefixfile1line1=v
		elif k=='--prefix-first-line-of-file-2':
			prefixfile2line1=v		
		elif k=='--with':

			if headerFieldReplaceeSelector==1:
				f1hreplace[headerFieldReplaceeKey]=v
			elif headerFieldReplaceeSelector==2:
				f2hreplace[headerFieldReplaceeKey]=v
			else:
				print >> stderr,"--with not preceded by --r1 or --r2. Abort"
				#printUsageAndExit(programName)
				exit()
						
			headerFieldReplaceeSelector=0
	if warningLevel>0:		
		print >> sys.stderr,"seperator is ["+separator+"]";
	joinFiles(ofilename,filename1,filename2,file1f0,file2f0,separator,printFile2Only,skipKeyColFile2,keyInternalSeparator,warningLevel,includeEveryFile1Rows,File2FillIn,warnDuplicateKeys,replaceFile1ColsByFile2,replaceFile1ColsByFile2Cols,stripFields,f1hreplace,f2hreplace,headerRow,prefixfile1line1,prefixfile2line1)

if __name__=='__main__':
	joinu_Main()



